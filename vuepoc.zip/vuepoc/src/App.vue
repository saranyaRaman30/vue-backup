<template>
  <div id="app">
    <router-view/>
    <!-- <sample></sample> -->
    <grid></grid>
  </div>
</template>

<script>
import sample from './components/sample';
import grid  from './components/grid';
import demoGrid  from './components/demoGrid';


export default {
  name: 'App',
  components: {
    sample,
    grid,
    demoGrid
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
