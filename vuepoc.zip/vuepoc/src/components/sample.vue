<template>
  <div>
    <p>sai</p>
    <p>{{title}}</p>
    <button @click="clicked">Click me!</button>
    <!-- <router-link to="/hello">Go to router</router-link> -->
  </div>
</template>

<script>
export default {
  name: 'sample',
  data () {
    return {
      title: 'vue poc'
    }
  },
  created(){
    console.log(1);
  },
  mounted(){
   console.log(2);
  },
  updated(){
   console.log(3);
  },
  destroyed(){
 
  },
  methods:{
    clicked(){
        console.log("gomathi");
        this.title = "my example"
    }
  }
}
</script>

<style scoped>

</style>
