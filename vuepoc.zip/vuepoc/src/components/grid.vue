<template>
  <div id="grid">
      <form id="search">
        Search <input name="query" v-model="searchQuery">
      </form>
      <div class="addtobag" v-if ="isClicked">
          <div >
              {{gridData[tableId].Model}}
          </div>
      </div>
      <demoGrid
        :heroes="gridData"
        :columns="gridColumns"
        :filter-key="searchQuery"
         @selected="setEntry"
      >
      </demoGrid>
    </div>
</template>

<script>

import demoGrid from './demoGrid'
import Vue from 'vue'
import EventBus from '../event-bus.js'


export default {
  name: 'grid',
    components: {
        demoGrid
    },
    data(){
        return {
        searchQuery: "",
        isClicked:false,
        tableId:'',
        gridColumns: ["id","Brand", "Model","Price","addToCart"],
        gridData: [
        {id:0, Brand: "iphone", Model: "iphone8",Price:38900, addToCart: "AddMe" },
        {id:1, Brand: "samsung",  Model: "m30s",Price:15999, addToCart: "AddMe" },
        {id:2, Brand: "RealMe", Model: "fivePro", Price:17000,addToCart: "AddMe" },
        {id:3, Brand: "Vivo", Model: "z1X",Price:16990 ,addToCart: "AddMe" }
        ]
        }
    },
    mounted () {
        EventBus.$on('clickValue', (value1,value2) => {
        this.isClicked = value1;
        this.tableId = value2;
        })
    },
    methods:{
        setEntry(entry){
            this.entry = entry
        }
    }
        
}
</script>
<style lang="scss" >
  @import '../style/grid.scss';
</style>